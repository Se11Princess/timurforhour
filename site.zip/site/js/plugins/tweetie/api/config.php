<?php
    /**
     * Your Twitter App Info
     */

    // Consumer Key
    define('CONSUMER_KEY', 'wUgKdatZSvLqvNBrqyaHWun9M');
    define('CONSUMER_SECRET', '3aCpLBSyQy5M7whbe7CbhrqtQaPQdF4YQ4yVpCGgQgu8BGQmsA');

    // User Access Token
    define('ACCESS_TOKEN', '887278135854718976-KTNhdBlocRUE1KPU4IThIXcl11mjALG');
    define('ACCESS_SECRET', 'r2138CnEaT39xVjcAqDzGvE4xjMBTA6naliIahnvR22N8');

	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));